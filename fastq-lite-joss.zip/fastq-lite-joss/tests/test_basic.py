
import subprocess
import sys

def test_help():
    result = subprocess.run([sys.executable, "fastq-lite.py", "--help"], 
                            capture_output=True, text=True)
    assert "usage" in result.stdout.lower()
    assert result.returncode == 0
